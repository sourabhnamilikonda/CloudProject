import boto3
import os
import sys
import urllib

s3_cli = boto3.cli('s3')

def handler(event, context):
    for rec in event['Records']:
        bucket = rec['s3']['bucket']['name']
        key = rec['s3']['object']['key']
        raw_key = urllib.parse.unquote_plus(key)
        download_path = '/tmp/{}'.format(key)
        
        s3_cli.download_file(bucket, raw_key, download_path)
        
        fileName, fileExtension = os.path.splitext(download_path)
        console.log(fileExtension)
        if fileExtension == 'jpg'
            s3_client.upload_file(upload_path,
             '{}'.format(bucket),
             'moved-{}'.format(raw_key),
             ExtraArgs={'ContentType': 'image/jpeg'})